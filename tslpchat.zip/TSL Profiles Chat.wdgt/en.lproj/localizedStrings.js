var localizedStrings = new Object;

localizedStrings["Done"] = "Done";
localizedStrings['TSLPName'] = 'tsl profiles';
localizedStrings['UserIDString'] = 'Second Life Name:';
localizedStrings['APIKeyString'] = 'TSLP Password:';
localizedStrings['LoadingText'] = 'Loading...';
localizedStrings['SendBtnValue'] = 'Send';
